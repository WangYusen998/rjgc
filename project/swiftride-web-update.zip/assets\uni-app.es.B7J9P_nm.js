import{_ as a,$ as s,a0 as o,a1 as r,a2 as t}from"./index-BmSB-Uti.js";const e=(o,r=0)=>(r,e=s())=>{!t&&a(o,r,e)},i=e(o,3),m=e(r,2);export{m as a,i as o};
